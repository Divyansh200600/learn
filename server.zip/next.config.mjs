const nextConfig = {
  images: {
    domains: [
      'via.placeholder.com',
      'firebasestorage.googleapis.com',
      'www.w3schools.com',
      '1000logos.net',
    ],
  },
};

export default nextConfig;