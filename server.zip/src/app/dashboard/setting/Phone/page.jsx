import React from 'react'

export default function SettignPhonePage() {
  return (
    <div>SettignPhonePage</div>
  )
}
