import React from 'react'

export default function SettignDesktopPage() {
  return (
    <div><h1 className='text-5xl text-black'>SettignDesktopPage</h1></div>
  )
}
