import React from 'react'

export default function NotificationDesktopScreen() {
  return (
    <div className='pt-8 text-white text-5xl'> 
        <h1>Notification Screen</h1>
    </div>
  )
}
