
const AchievementsPage = () => {
 

  return (
    <div>
      <h1 className="text-6xl font-bold text-black mb-12 text-center">Achievement</h1>
     
    </div>
  );
};

export default AchievementsPage;