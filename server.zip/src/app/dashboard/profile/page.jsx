import React from 'react'

export default function ProfilePage() {
  return (
    <div> 
        <h1>hello</h1>
    </div>
  )
}
