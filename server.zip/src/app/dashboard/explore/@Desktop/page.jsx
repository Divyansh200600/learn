import React from 'react'

export default function ExploreDesktopScreen() {
  return (
    <div className='pt-8 text-white text-5xl'> 
        <h1>Explore Screen</h1>
    </div>
  )
}
