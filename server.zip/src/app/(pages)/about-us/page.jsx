import React from 'react'

export default function AboutUs() {
  return (
    <div><h1>
        About us
        </h1></div>
  )
}

// localhost:3000/pages/about-us
