import React from 'react'

export default function PhoneSettingScreen() {
  return (
    <div>PhoneSettingScreen</div>
  )
}
