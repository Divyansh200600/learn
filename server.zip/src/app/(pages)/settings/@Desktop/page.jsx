import React from 'react'

export default function DesktopSettingScreen() {
  return (
    <div>DesktopSettingScreen</div>
  )
}
