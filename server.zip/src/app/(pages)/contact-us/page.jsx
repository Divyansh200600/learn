import React from 'react'

export default function Contactus() {
  return (
    <div> 
        <h1 className='text-center text-orange-500 text-2xl'>
            Contact Us 
        </h1>
    </div>
  )
}
