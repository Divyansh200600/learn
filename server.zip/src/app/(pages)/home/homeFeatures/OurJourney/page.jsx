import React from 'react';

const JourneyPage = () => {

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-800 text-white">
 <h1>Hello Its Now Under Working :)</h1>
    </div>
  );
};

export default JourneyPage;
