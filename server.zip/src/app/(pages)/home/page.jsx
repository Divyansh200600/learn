import React from 'react'

export default function DefaultHomeScreen() {


  return (
    <div>DefaultHomeScreen</div>
  )
}
