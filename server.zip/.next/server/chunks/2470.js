"use strict";exports.id=2470,exports.ids=[2470],exports.modules={22470:(e,r,i)=>{i.r(r),i.d(r,{default:()=>D});var n=i(10326),l=i(17577),t=i(26670),o=i.n(t),s=i(21886);let a=s.ZP.div`
  display: flex;
  justify-content: space-between;
  padding: 50px;
  width: 150%;
  background-color: #151b25;
  color: white;
  font-family: Arial, sans-serif;
`,d=s.ZP.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  left: 50px;
  bottom: -1750px;
  background-color: #1a1a1a;
  padding: 20px;
  border-radius: 10px;
`,c=s.ZP.button`
  background-color: grey;
  color: #001524;
  padding: 10px;
  font-size: 1.2rem;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-bottom: 10px;

  &:hover {
    background-color: #58b4d1;
    color: white;
  }

  ${({active:e})=>e&&`
    background-color: #58b4d1;
    color: white;
  `}
`,x=s.ZP.div`
  flex: 1;
  margin-right: 20px;
`,p=s.ZP.h1`
  font-size: 2.5rem;
`,h=s.ZP.ul`
  list-style-type: none;
  padding: 0;
  margin: 20px 0;
  li {
    margin: 10px 0;
    display: flex;
    align-items: center;
    gap: 10px;
  }
`,g=s.ZP.div`
  display: flex;
  justify-content: space-around;
  background-color: #126782;
  padding: 15px;
  border-radius: 10px;
  margin-top: 20px;
  gap: 20px;

`,f=s.ZP.div`
  text-align: center;
  font-size: 1rem; `,j=s.ZP.div`
  flex: 1;
  background-color: #008083;
  padding: 30px;
  border-radius: 10px;
`,m=s.ZP.form`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,u=s.ZP.input`
  padding: 10px;
  font-size: 1rem;
  border: none;
  border-radius: 5px;
`,A=s.ZP.button`
  background-color: #d88e45;
  color: white;
  padding: 10px;
  font-size: 1.2rem;
  border: none;
  border-radius: 5px;
  cursor: pointer;
`;function b(){let[e,r]=(0,l.useState)("full-stack");return(0,n.jsxs)(n.Fragment,{children:[n.jsx(o(),{children:n.jsx("title",{children:"Bootcamp"})}),(0,n.jsxs)(d,{children:[n.jsx(c,{active:"full-stack"===e,onClick:()=>r("full-stack"),children:"Full Stack"}),n.jsx(c,{active:"data-analyst"===e,onClick:()=>r("data-analyst"),children:"Data Analyst"})]}),(0,n.jsxs)(a,{children:[n.jsx(x,{children:"full-stack"===e?(0,n.jsxs)(n.Fragment,{children:[n.jsx(p,{children:"Full Stack Web Development Bootcamp"}),n.jsx("p",{children:"Available in two formats MERN & Spring-boot, learn by practice and making real world projects."}),(0,n.jsxs)(h,{children:[n.jsx("li",{children:"✓ Placement Assistance"}),n.jsx("li",{children:"✓ 1:1 Mentorship"}),n.jsx("li",{children:"✓ Faculty from MAANG"})]}),(0,n.jsxs)(g,{children:[(0,n.jsxs)(f,{children:[n.jsx("div",{children:"90%"}),n.jsx("div",{children:"Placement Rate"})]}),(0,n.jsxs)(f,{children:[n.jsx("div",{children:"1200+"}),n.jsx("div",{children:"Hiring Partners"})]}),(0,n.jsxs)(f,{children:[n.jsx("div",{children:"128%"}),n.jsx("div",{children:"Average Hike"})]}),(0,n.jsxs)(f,{children:[n.jsx("div",{children:"1.5 L+"}),n.jsx("div",{children:"Learners"})]})]})]}):"data-analyst"===e?(0,n.jsxs)(n.Fragment,{children:[n.jsx(p,{children:"Data Analyst Bootcamp"}),n.jsx("p",{children:"Learn data analysis techniques, tools, and methodologies. Prepare for a career in data analytics with hands-on projects."}),(0,n.jsxs)(h,{children:[n.jsx("li",{children:"✓ Data Analysis Techniques"}),n.jsx("li",{children:"✓ Tools & Methodologies"}),n.jsx("li",{children:"✓ Real-World Projects"})]}),(0,n.jsxs)(g,{children:[(0,n.jsxs)(f,{children:[n.jsx("div",{children:"85%"}),n.jsx("div",{children:"Placement Rate"})]}),(0,n.jsxs)(f,{children:[n.jsx("div",{children:"1000+"}),n.jsx("div",{children:"Hiring partners"})]}),(0,n.jsxs)(f,{children:[n.jsx("div",{children:"115%"}),n.jsx("div",{children:"Average Hike"})]}),(0,n.jsxs)(f,{children:[n.jsx("div",{children:"1.2 L+"}),n.jsx("div",{children:"Learners"})]})]})]}):void 0}),(0,n.jsxs)(j,{children:[(0,n.jsxs)("h2",{children:["Book a ",n.jsx("span",{style:{color:"#f27059"},children:"Free live webinar"})," to know more"]}),(0,n.jsxs)(m,{children:[n.jsx(u,{type:"text",placeholder:"Enter name",required:!0}),n.jsx(u,{type:"email",placeholder:"Email",required:!0}),n.jsx(u,{type:"tel",placeholder:"Phone number",required:!0}),(0,n.jsxs)("div",{children:[n.jsx("p",{children:"Experience:"}),(0,n.jsxs)("div",{style:{marginBottom:"10px"},children:[n.jsx("input",{type:"radio",id:"technical",name:"experience",value:"technical"}),n.jsx("label",{htmlFor:"technical",style:{marginLeft:"10px"},children:"Working Professional - Technical Roles"})]}),(0,n.jsxs)("div",{style:{marginBottom:"10px"},children:[n.jsx("input",{type:"radio",id:"non-technical",name:"experience",value:"non-technical"}),n.jsx("label",{htmlFor:"non-technical",style:{marginLeft:"10px"},children:"Working Professional - Non Technical"})]}),(0,n.jsxs)("div",{style:{marginBottom:"10px"},children:[n.jsx("input",{type:"radio",id:"final-year",name:"experience",value:"final-year"}),n.jsx("label",{htmlFor:"final-year",style:{marginLeft:"10px"},children:"College Student - Final Year"})]}),(0,n.jsxs)("div",{style:{marginBottom:"10px"},children:[n.jsx("input",{type:"radio",id:"pre-final",name:"experience",value:"pre-final"}),n.jsx("label",{htmlFor:"pre-final",style:{marginLeft:"10px"},children:"College Student - 1st to Pre-final Year"})]}),(0,n.jsxs)("div",{style:{marginBottom:"10px"},children:[n.jsx("input",{type:"radio",id:"others",name:"experience",value:"others"}),n.jsx("label",{htmlFor:"others",style:{marginLeft:"10px"},children:"Others"})]})]}),n.jsx(A,{type:"submit",children:"Continue booking webinar"})]})]})]})]})}var y=i(46226);let v={src:"/_next/static/media/avatar-design.5974d6f5.png",height:512,width:512,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAARVBMVEWlgXL31cc8PDzuvJ3Kn4nsu508PDxVRTtuTTmOalOipaZSWlptdHRtTzk2NjY2NjSwkn/ftptGRETwyKvGlZX21cnguryOTCI6AAAAEXRSTlMBMMn9k1+qG+h75/v8OoSEKOUtfbAAAAAJcEhZcwAAdhwAAHYcAafCeOoAAAAZdEVYdFNvZnR3YXJlAHd3dy5pbmtzY2FwZS5vcmeb7jwaAAAAO0lEQVR4nB3Gxw0AIAwEsKOGjhLK/qMi4pcB9JQIX2bOGs/sNWGtoDHOGQA0yzllEKK0e5tEWKl7V7EPN4oB/lPu7eAAAAAASUVORK5CYII=",blurWidth:8,blurHeight:8};var k=i(79102);let w=s.ZP.div`
  display: flex;
  width: 1200px;
  position: relative;
  left: -290px;
  justify-content: center;
  padding: 50px;
  background-color: #151b25; /* Updated background color */
`,P=s.ZP.div`
  background-color: #124559; /* Updated card color */
  color: white;
  border-radius: 20px;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  width: 450px;
  margin: 0 20px;
  padding: 20px;
  position: relative;
`,Z=s.ZP.div`
  position: absolute;
  top: 10px;
  left: 6px;
  background-color: ${e=>e.bgColor||"#ff5700"};
  color: white;
  border-radius: 10px;
  padding: 5px 10px;
  font-size: 0.9rem;
`,C=s.ZP.h2`
  font-size: 1.5rem;
  margin-top: 20px;
`,E=s.ZP.p`
  margin: 10px 0;
`,F=s.ZP.ul`
  list-style-type: none;
  padding: 0;
  margin: 10px 0;
  li {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    font-size: 0.9rem;
    &:before {
      content: '✔️';
      margin-right: 10px;
      color: #00ff8c;
    }
  }
`,B=s.ZP.button`
  background-color: white;
  color: #58b4d1;
  border: none;
  border-radius: 5px;
  padding: 10px;
  font-size: 1.5rem;
  cursor: pointer;
  width: 100%;
  margin-top: 20px;
  &:hover {
    background-color: #58b4d1;
    color: white ;
  }
`;s.ZP.div`
  text-align: center;
  margin-bottom: 50px;
  h1 {
    font-size: 2.5rem;
    color: #000000;
  }
  span {
    color: #ff6f61;
    display: block;
    margin-top: 10px;
    font-size: 1.2rem;
  }
`;let R=s.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 30px 0;
  img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
  }
`,S=()=>(0,n.jsxs)(n.Fragment,{children:[n.jsx("h1",{className:"text-4xl mx-auto font-bold text-blue-900 mb-9 text-center",children:"Enhanced Courses for Exponential Growth in Skills"}),(0,n.jsxs)(w,{children:[(0,n.jsxs)(P,{children:[n.jsx(Z,{bgColor:"#8a5a44",children:"Newly Launched for Students"}),n.jsx(R,{children:n.jsx(y.default,{src:k.Z,alt:"Avatar"})}),n.jsx(C,{children:"PulseZest-Learning Zesty Tech"}),n.jsx(E,{children:"2 years program for 1st to pre-final year college students"}),(0,n.jsxs)(F,{children:[n.jsx("li",{children:"Get job assistance"}),n.jsx("li",{children:"Complete CS education"}),n.jsx("li",{children:"2 year flexible student track"})]}),n.jsx(B,{children:"Explore Offers"})]}),(0,n.jsxs)(P,{children:[n.jsx(Z,{bgColor:"#2b2d42",children:"For Professionals"}),n.jsx(R,{children:n.jsx(y.default,{src:v,alt:"Avatar"})}),n.jsx(C,{children:"Job Bootcamp"}),n.jsx(E,{children:"Extensive program for working professionals for get Dream Jobs"}),(0,n.jsxs)(F,{children:[n.jsx("li",{children:"Get job assistance"}),n.jsx("li",{children:"FSD/Data career tracks"}),n.jsx("li",{children:"9 months intensive bootcamp"})]}),n.jsx(B,{children:"Join Webinar"})]})]})]}),D=()=>{let[e,r]=(0,l.useState)("BootCamp"),i=e=>{r(e)};return(0,n.jsxs)("div",{style:{backgroundColor:"#ced4da",minHeight:"100vh",padding:"20px",display:"flex",flexDirection:"column",alignItems:"center"},children:[(0,n.jsxs)("nav",{style:{backgroundColor:"#001524",padding:"10px 0",width:"25%",display:"flex",justifyContent:"center",borderRadius:"15px"},children:["        ",n.jsx("button",{style:{backgroundColor:"BootCamp"===e?"#ffffff":"transparent",color:"BootCamp"===e?"#001524":"#ffffff",border:"none",padding:"10px 20px",cursor:"pointer",fontSize:"1rem",borderRadius:"5px",marginRight:"10px",transition:"background-color 0.3s, color 0.3s"},onClick:()=>i("BootCamp"),children:"Webinar"}),n.jsx("button",{style:{backgroundColor:"Webinar"===e?"#ffffff":"transparent",color:"Webinar"===e?"#001524":"#ffffff",border:"none",padding:"10px 20px",cursor:"pointer",fontSize:"1rem",borderRadius:"5px",transition:"background-color 0.3s, color 0.3s"},onClick:()=>i("Webinar"),children:"BootCamp"})]}),(0,n.jsxs)("div",{style:{marginTop:"20px",width:"100%",maxWidth:"600px"},children:["BootCamp"===e&&n.jsx(b,{}),"Webinar"===e&&n.jsx(S,{})]})]})}},79102:(e,r,i)=>{i.d(r,{Z:()=>n});let n={src:"/_next/static/media/boy.2f7903e4.png",height:512,width:512,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAaVBMVEVzpcMnKD4AACODrMcrMEZmw/geFiY1M0Vly/9ov/Fnyf34v55LcY9FdpyZc2tDcpbrwWlLeqClk3Kdgl/jqlFlr9pEUGlmst//sIJtT1FaZHZn0f9UfKA+PlGdprVOirTmrpXspoEnJz7oRBRWAAAAG3RSTlMC4Sf7ysEh/alvzP5eWP2T95KwsPj9/f38/f1DscJZAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAERJREFUeJwFwQUCgDAMBLCbdoI7dAb/fyQJgF7rDgBcuofkAM/qioo9DO9vO9kg1KPFpwaMH5VCNMOKTJSFBeS6TYvED3v5A5JOKYiZAAAAAElFTkSuQmCC",blurWidth:8,blurHeight:8}}};